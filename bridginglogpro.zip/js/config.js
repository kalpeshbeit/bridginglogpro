
var krms_config ={		
	'ApiUrl':"http://callabhi.com/eventmanage/api/v1/index.php?action=",	
	'ServerUrl':"http://callabhi.com/eventmanage",
	'append_api':"format/json",
	'DialogDefaultTitle':"",
	'pushNotificationSenderid':"684191859302",
	'facebookAppId':"796560520473152"
};